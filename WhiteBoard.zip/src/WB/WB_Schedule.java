package WB;

import java.awt.Color;

import javax.swing.JPanel;

public class WB_Schedule extends JPanel {

	public WB_Schedule(){
		setBackground(Color.white);
	}

}
