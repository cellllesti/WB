package WB;

import java.awt.Color;

import javax.swing.JPanel;

public class WB_Tip extends JPanel{
	public WB_Tip(){
		setBackground(Color.white);
	}
}
