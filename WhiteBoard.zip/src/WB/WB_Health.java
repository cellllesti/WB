package WB;

import java.awt.Color;

import javax.swing.JPanel;

public class WB_Health extends JPanel {
	
	public WB_Health(){
		setBackground(Color.white);
		setLayout(null);
	}

}
