package WB;

public interface Use_showMessage {
	public void showMessage(String title, String message);
}
